<?php
	session_start();
	include "header.php";
?>

	<main>
		<div class="content">

			<div class="head">Наши контакты</div>
			<p>Адрес: <b>Северо-западный микрорайон 14</b></p>
			<p>Номер телефона: <b>71234567890</b></p>
			<p>Email: <b>Comnany@gmail.com</b></p>
			
			<div class="head">Наше местоположение</div>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5511.862551995296!2d95.64278931982358!3d56.255668554963236!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5cdecdbe08fe432d%3A0xcb34ca2f60c30607!2z0JTQtdGA0LXQstC-0L7QsdGA0LDQsdCw0YLRi9Cy0LDRjtGJ0LjQuSDQt9Cw0LLQvtC0LiDQmtCw0L3RgdC6Lg!5e0!3m2!1sru!2sru!4v1711912737403!5m2!1sru!2sru" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

		</div>
	</main>

<?php include "footer.php" ?>